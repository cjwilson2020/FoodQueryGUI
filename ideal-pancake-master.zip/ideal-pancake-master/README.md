# README
## X-Team 53 Members
Christopher Wilson: cwilson32@wisc.edu

Josiah Fee: jfee2@wisc.edu

Aaron Kelly: amkelly3@wisc.edu

Chloe Chan: cchan58@wisc.edu

*All four members were a part of the same X-Team*

## About
An application to assist in meal planning. Allows for import of a variety of foods. Offers filtering based on food name and nutritional information. Ability to add foods to a meal and analyze the overall nutritional content. Can save a created meal to a file. 
